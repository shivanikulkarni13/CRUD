﻿namespace EComWFE.App_Data
{


    partial class NewDataSet
    {
    }
}
